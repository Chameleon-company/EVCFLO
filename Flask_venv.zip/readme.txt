This python virtual environment can be used to host the Chameleon Flask web server.

Unzip this .zip file to a new folder.
Copy the 'server' folder into this new folder just created.
Launch the virtual environment (navigate to Scripts folder and run 'activate')
navigate to the server folder and launch the server ('python server.py')
